# K20-ThietKeWeb
bài tập môn thiết kế web và triển khai hệ thống phần mềm - TRANHOAINAM
DAINAM UNIVERSITY@PM-701-PC1 UCRT64 /d/2071020137-Trần hoài nam (main)
$ pwd
/d/2071020137-Trần hoài nam

DAINAM UNIVERSITY@PM-701-PC1 UCRT64 /d/2071020137-Trần hoài nam (main)
$ git rev-parse --show-toplevel
D:/2071020137-Trần hoài nam

DAINAM UNIVERSITY@PM-701-PC1 UCRT64 /d/2071020137-Trần hoài nam (main)
$ git rev-parse --show-toplevel
D:/2071020137-Trần hoài nam

DAINAM UNIVERSITY@PM-701-PC1 UCRT64 /d/2071020137-Trần hoài nam (main)
$ git status
On branch main

No commits yet

Untracked files:
  (use "git add <file>..." to include in what will be committed)
        "2071020137-Tr\341\272\247n ho\303\240i nam/"
        HOCCSS.html
        asset/
        css/
        ket-qua.html
        tb.html
        tb1.css

nothing added to commit but untracked files present (use "git add" to track)

DAINAM UNIVERSITY@PM-701-PC1 UCRT64 /d/2071020137-Trần hoài nam (main)
$ git add index.html
fatal: pathspec 'index.html' did not match any files

DAINAM UNIVERSITY@PM-701-PC1 UCRT64 /d/2071020137-Trần hoài nam (main)
$ git add HOCCSS.html

DAINAM UNIVERSITY@PM-701-PC1 UCRT64 /d/2071020137-Trần hoài nam (main)
$ git diff --staged
diff --git a/HOCCSS.html b/HOCCSS.html
new file mode 100644
index 0000000..f2ff5b7
--- /dev/null
+++ b/HOCCSS.html
@@ -0,0 +1,76 @@
+<!DOCTYPE html>
+<html lang="vi">
+<head>
+    <meta charset="UTF-8">
+    <meta name="viewport" content="width=device-width, initial-scale=1.0">
+    <title>Lá Coffee</title>
+    <link rel="stylesheet" href="css/hocCSS.css">
+</head>
+<body>
+  <header>
+    <nav class="nav-sive">
+      <ul>
+        <li><a href="#home">Trang chủ</a></li>
+        <li><a href="#menu">Thực đơn</a></li>
+        <li><a href="#contact">Liên hệ</a></li>
+      </ul>
+    </nav>
+  </header>
+
+  <section id="home">
qq
DAINAM UNIVERSITY@PM-701-PC1 UCRT64 /d/2071020137-Trần hoài nam (main)
$ git commit -m "baseline: initial version"
[main (root-commit) ad2178f] baseline: initial version
 1 file changed, 76 insertions(+)
 create mode 100644 HOCCSS.html

DAINAM UNIVERSITY@PM-701-PC1 UCRT64 /d/2071020137-Trần hoài nam (main)
$ git add HOCCSS.html

DAINAM UNIVERSITY@PM-701-PC1 UCRT64 /d/2071020137-Trần hoài nam (main)
$ git commit -m "La -> Hoa"
[main 2efe85a] La -> Hoa
 1 file changed, 1 insertion(+), 1 deletion(-)

DAINAM UNIVERSITY@PM-701-PC1 UCRT64 /d/2071020137-Trần hoài nam (main)
$ git log --oneline --graph --decorate
* 2efe85a (HEAD -> main) La -> Hoa
* ad2178f baseline: initial version
